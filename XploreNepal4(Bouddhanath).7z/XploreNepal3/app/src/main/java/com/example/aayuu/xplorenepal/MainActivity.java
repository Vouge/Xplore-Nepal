package com.example.aayuu.xplorenepal;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.FrameMetricsAggregator;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout mDrawerLayout;
    private ActionBarDrawerToggle mToggle;
    private FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mAuth = FirebaseAuth.getInstance();

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


       Intent intent=getIntent();
        final String Fragment_Selected = intent.getStringExtra("Fragment_Selected");
        if(Fragment_Selected ==  null) {
            DisplayFragment(R.id.nav_home);

        }else{
            ActivityToFragment(Fragment_Selected);
        }

    }
    @Override
    protected void onStart() { // Called anytine when app is poped in for example when app is maximized after minimizing
        super.onStart();
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            sendToLoginpage();
        }
    }

    private void ActivityToFragment(String fragment_selected) {
        android.support.v4.app.Fragment fragment = null;
        switch (fragment_selected){
            case "Home":
                fragment = new HomeFragment();
                break;
            case "Destination":
                fragment = new DestinationsFragment();
                break;
            case "Travel":
                fragment = new TravelFragment();
                break;
            case "My Trips":
                fragment = new android.support.v4.app.Fragment();
                break;
            case "About us":
                fragment = new AboutusFragment();
                break;

        }
        if(fragment != null){
            FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.MyFrameLayout, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }
    /*
        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            // Handle action bar item clicks here. The action bar will
            // automatically handle clicks on the Home/Up button, so long
            // as you specify a parent activity in AndroidManifest.xml.
            int id = item.getItemId();

            //noinspection SimplifiableIfStatement

            if (id == R.id.action_settings) {
                return true;

            }

            return super.onOptionsItemSelected(item);
        }
    */
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        if (item.getItemId()==R.id.nav_signout) {

                signout();
                return true;}


            else{
                DisplayFragment(item.getItemId());
                return true;
        }

    }

    public void DisplayFragment(int Id){
        android.support.v4.app.Fragment fragment = null;
        switch (Id){
            case R.id.nav_home:
                fragment = new HomeFragment();
                break;

            case R.id.nav_destination:
                fragment = new DestinationsFragment();

                break;
            case R.id.nav_travel:
                fragment = new TravelFragment();

                break;
            case R.id.nav_mytrips:
                fragment = new MyTripsFragment();
                break;
            case R.id.nav_aboutus:
                fragment = new AboutusFragment();
                break;

        }

        if(fragment != null){
            android.support.v4.app.FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.MyFrameLayout, fragment);
            ft.commit();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
    }


    private void signout() {
        mAuth.signOut();
        sendToLoginpage();
    }

    private void sendToLoginpage() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();//user cant come back using back button


    }

}


