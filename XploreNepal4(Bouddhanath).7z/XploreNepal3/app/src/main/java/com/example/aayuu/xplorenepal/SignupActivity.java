package com.example.aayuu.xplorenepal;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignupActivity extends AppCompatActivity {
    private EditText reg_email_field;
    private EditText reg_pass_field;
    private EditText reg_confirm_pass_field;
    private Button regbtn;
    private Button loginregbutn ;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        ActionBar actionBar = getSupportActionBar();
        actionBar.hide();

        mAuth = FirebaseAuth.getInstance();

        reg_email_field= (EditText)findViewById(R.id.reg_email);
        reg_pass_field= (EditText)findViewById(R.id.reg_password);
        reg_confirm_pass_field=(EditText)findViewById(R.id.reg_confirm_pass);
        regbtn= (Button)findViewById(R.id.reg_btn);
        loginregbutn=(Button)findViewById(R.id.login_reg_btn);

        loginregbutn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainintent = new Intent(SignupActivity.this,MainActivity.class);
                startActivity(mainintent);

            }
        });

        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mail= reg_email_field.getText().toString();
                String pass= reg_pass_field.getText().toString();
                String confirm_pass = reg_confirm_pass_field.getText().toString();

                if(!TextUtils.isEmpty(mail)  && !TextUtils.isEmpty(pass)  && !TextUtils.isEmpty(confirm_pass)){
                    if (pass.equals(confirm_pass)){
                        mAuth.createUserWithEmailAndPassword(mail, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()){
                                    sendToMain();


                                }
                                else {
                                    String errorMsg= task.getException().getMessage();
                                    Toast.makeText(SignupActivity.this,"Error:"+errorMsg,Toast.LENGTH_LONG).show();
                                }

                            }
                        });

                    }else
                    {
                        Toast.makeText(SignupActivity.this,"Password doesn't matches",Toast.LENGTH_LONG).show();
                    }
                }

            }
        });



    }

    protected void onStart() {
        super.onStart();
        FirebaseUser currentuser = mAuth.getCurrentUser();
        if(currentuser != null)
        {
            sendToMain();
        }


    }

    private void sendToMain() {
        Intent mainintent = new Intent(SignupActivity.this,MainActivity.class);
        startActivity(mainintent);
        finish();

    }
}
