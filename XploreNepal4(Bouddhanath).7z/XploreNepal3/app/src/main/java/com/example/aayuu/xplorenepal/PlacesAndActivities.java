package com.example.aayuu.xplorenepal;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

import com.bumptech.glide.Glide;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import de.hdodenhof.circleimageview.CircleImageView;

public class PlacesAndActivities extends AppCompatActivity {

    private StorageReference mStorageRef;
    private CircleImageView baudhhanathCircleImageView;
    private CircleImageView pashupatinathCircleImageView;
    private CircleImageView swayambhuCircleImageView;
    private CircleImageView trekkingCircleImageView;
    private CircleImageView mountainbikingCircleImageView;
    private CircleImageView canoyingCircleImageView;
    private CircleImageView raftingCircleImageView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_places_and_activities);


        baudhhanathCircleImageView = (CircleImageView) findViewById(R.id.baudhhanathCircleImageView);
        pashupatinathCircleImageView = (CircleImageView) findViewById(R.id.pashupatinathCircleImageView);
        swayambhuCircleImageView = (CircleImageView) findViewById(R.id.swayambhuCircleImageView);
        trekkingCircleImageView = (CircleImageView) findViewById(R.id.trekkingCircleImageView);
        mountainbikingCircleImageView = (CircleImageView) findViewById(R.id.mountainbikingCircleImageView);
        canoyingCircleImageView = (CircleImageView) findViewById(R.id.canoyingCircleImageView);
        raftingCircleImageView = (CircleImageView) findViewById(R.id.raftingCircleImageView);

        mStorageRef = FirebaseStorage.getInstance().getReference();


        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2Fbauddhanath.jpg?alt=media&token=5a9a29bd-511c-4f9f-83fa-8b40795ba263")
                .into(baudhhanathCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2Fpashupatinath.jpg?alt=media&token=d92cc5b7-5974-4868-9f50-23a2d3a3a4ed")
                .into(pashupatinathCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Destinations%2Fswayambhu.jpg?alt=media&token=8a28ad25-60ee-4ce9-af4a-fd5f484116e6")
                .into(swayambhuCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Activities%2Ftrekking.jpg?alt=media&token=edd49be8-4b35-4495-9cde-9cbb199adbd3")
                .into(trekkingCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Activities%2Fmountainbiking.jpg?alt=media&token=9b0bdcf5-160e-4d46-83df-88267ef30736")
                .into(mountainbikingCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Activities%2Fcanoying.jpg?alt=media&token=30c49def-2226-45dd-b4e7-4b4cfb5d8369")
                .into(canoyingCircleImageView);

        Glide.with(this)
                .load("https://firebasestorage.googleapis.com/v0/b/xplorenepal123-9ed01.appspot.com/o/Activities%2Frafting.jpg?alt=media&token=960360f2-04d5-4666-97a3-363deb3ca8c5")
                .into(raftingCircleImageView);

        baudhhanathCircleImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(getApplicationContext(), BauddhanathLocation.class);
                startActivity(intent);

            }
        });



    }
}
